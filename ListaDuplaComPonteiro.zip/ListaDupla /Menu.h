int Menu()
{
	int op;
	
	system("cls");
	printf("1 - Inserir\n");
	printf("2 - Imprimir\n");
	printf("3 - Retirar\n");
	printf("4 - Esvaziar\n");
	printf("0 - Sair\n\n");
	printf("Qual a opcao desejada ?");
	scanf("%i",&op);
	
	return op;
}
