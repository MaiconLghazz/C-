no *Retirar(no *Z)
{
	 
	no *x, *aux;
	int valor;
	system("cls");
	
	printf("Qual valor deseja retirar ?");
	scanf("%d",&valor);
	
	for(x=Z;x!=NULL;x=x->prox)
	{
		
		if(x->dado==valor && x==Z)
		{
			aux=x->prox;
			free(x);
			system("cls");
			printf("Valor retirado !\n");
			_sleep(2000);
			return aux;
			
		}
		else if(x->dado==valor)
		{
			aux->prox=x->prox;
			free(x);
			system("cls");
			printf("Valor retirado !\n");
			_sleep(2000);
			return Z;
		}
		aux=x;
	}
	
	if(x==NULL)
	    system("cls");
		printf("Valor nao encontrado !\n");
		_sleep(2000);
		return Z;
}
