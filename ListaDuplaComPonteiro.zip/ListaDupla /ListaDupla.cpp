#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Estrutura.h"
#include "Menu.h"
#include "InserirIn.h"
#include "Imprimir.h"
#include "Retirar.h"
#include "Esvaziar.h"


main()
{
	
	int opcao,dado;
	no *ListaD = NULL;
	
	do
	{
		
		system("cls");
		opcao=Menu();
		
		if(opcao==1)
		{	
	      system("cls");
	      
		  printf("Digite o valor :");
	      scanf("%d",&dado);
	      
		  ListaD = InserirIn(ListaD,dado);
	    }
	    
		else if(opcao==2)
		{
			if(ListaD==NULL)
			{
			    system("cls");
				printf("Lista vazia  !\n");
				_sleep(1000);
			}
				
			else
			
			Imprimir(ListaD);
		}
		
			else if(opcao==3)
		{
			
			if(ListaD==NULL)
			{
			    system("cls");
				printf("Lista vazia !\n");
				_sleep(1000);
			}
				
			else
			
			ListaD = Retirar(ListaD);
		}
		
			else if(opcao==4)
		{
			
			if(ListaD==NULL)
			{
			    system("cls");
				printf("Lista vazia !\n");
				_sleep(1000);
			}
				
			else
			
			ListaD = Esvaziar(ListaD);
		}
	
	
	}while(opcao!=0);
}
