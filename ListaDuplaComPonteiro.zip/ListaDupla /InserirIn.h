

no *InserirIn(no *Z, int dado)
{
	
	no *Novo, *x ;
	int inse, pesq;
	Novo = (no*)malloc(sizeof(no));
	Novo->dado = dado;
	
	printf("\n1 - Inserir no inicio\n");
	printf("2 - Inserir no meio\n");
	printf("3 - Inserir no final\n\n");
	printf("Onde deseja inserir ?");
	scanf("%i",&inse);
	
if(inse==1)
{

	if(Z==NULL)
	{
		Novo->prox = Z;
		system("cls");
		printf("Valor Inserido !\n");
		_sleep(2000);
		return Novo;
	}
	
	else 
	{
		for (x=Z; x!=NULL; x=x->prox)
		{
		   if(x->prox==NULL)
		   {
		   Novo->prox = x->prox;
		   x->prox = Novo;
		   Novo->ant = x;
		   system("cls");
		   printf("Valor Inserido !\n");
	   	   _sleep(2000);
	       return Z;	
	       }
	    }
	}
}

else if(inse==2)
{
	
	if(Z==NULL)
    {
    	Novo->prox = Z;
        system("cls");
		printf("Valor Inserido !\n");
		_sleep(2000);
		return Novo;
	}
	
    else
	{
		printf("\nInserir apos qual valor? ");
		scanf("%d",&pesq);
		
		for(x=Z;x!=NULL;x=x->prox)
		{
			
			if ( pesq==x->dado && x->prox == NULL)
			{ 
			    system("cls");
				printf("Nao e possivel adicionar nessa posicao !!");
				_sleep(2000);
				return Z;
		
			}
			else if(pesq==x->dado)
			{
				x->ant = Novo;
				Novo->prox = x->prox;
				Novo->ant = x;
				x->prox = Novo;
				system("cls");
		        printf("Valor Inserido !\n");
		        _sleep(2000);
				return Z;
			}
		}
	}
}

else if(inse==3)
{
	
	if(Z==NULL)
    {
    	Novo->prox = Z;
    	system("cls");
		printf("Valor Inserido !\n");
		_sleep(2000);
		return Novo;
	}
	
	else
	{
	      Z->ant = Novo->prox;
	      Novo->prox = Z;
	      Z->ant = Novo;
	      system("cls");
		  printf("Valor Inserido !\n");
		  _sleep(2000);
	      return Novo;	
	}
}

}
