void Imprimir (no *z)
{
	
	no *x;
	system("cls");
	
	for(x=z;x!=NULL;x=x->prox)
	{
		printf("( %d ) ->",x->dado);
    }
    _sleep(1000);
}
