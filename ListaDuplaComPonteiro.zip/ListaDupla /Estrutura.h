struct no{
	
	int dado;
	no *prox, *ant;
	
};
